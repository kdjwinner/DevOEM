package com.ktf.oem.test;

import java.util.List;

public class TestBean2 {
	private String file;
	private String title;
	private String cate_code;
	private List<TestBean2> testBean2List;
	
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCate_code() {
		return cate_code;
	}
	public void setCate_code(String cate_code) {
		this.cate_code = cate_code;
	}
	public List<TestBean2> getTestBean2List() {
		return testBean2List;
	}
	public void setTestBean2List(List<TestBean2> testBean2List) {
		this.testBean2List = testBean2List;
	}	
}
