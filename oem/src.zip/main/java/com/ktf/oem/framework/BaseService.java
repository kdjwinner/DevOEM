
package com.ktf.oem.framework;

public class BaseService {

}
