package com.ktf.oem.data;

public class RecommandSongBean {
	private XringInfo new_song;
	private XringInfo best_song;
	private XringInfo week_song;
	
	public XringInfo getNew_song() {
		return new_song;
	}
	public void setNew_song(XringInfo new_song) {
		this.new_song = new_song;
	}
	public XringInfo getBest_song() {
		return best_song;
	}
	public void setBest_song(XringInfo best_song) {
		this.best_song = best_song;
	}
	public XringInfo getWeek_song() {
		return week_song;
	}
	public void setWeek_song(XringInfo week_song) {
		this.week_song = week_song;
	}

}
