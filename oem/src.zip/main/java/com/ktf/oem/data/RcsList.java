package com.ktf.oem.data;

import java.util.List;

public class RcsList {
	
	private List<RING> rcsList;	
	
	public List<RING> getRcsList() {
		return rcsList;
	}

	public void setRcsList(List<RING> rcsList) {
		this.rcsList = rcsList;
	}


	

}