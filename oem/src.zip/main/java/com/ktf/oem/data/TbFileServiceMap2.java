package com.ktf.oem.data;

import java.util.List;

public class TbFileServiceMap2 {
	private int cate_code;                 
	private int file_scp_id;               
	private int file_sub_cpid;               
	private int file_sort;               
	private String cate_name;               
	private String file_scp_svname;               
	private int cate_code1;               
	private int cate_code2;               
	private int cate_code3;               
	private String cate_name1;               
	private String cate_name2;               
	private String cate_name3;               
	private int file_count;               
	private int file_sort1;               
	private int file_sort2;               
	private int file_sort3;               
	private String file_regdate;               
	private String file_title;               
	private String file_singer;               
	private String file_keyword;               
	private String file_scp;               
	private String file_sub_cp;               
	private int file_seq;               
	private String scp_sv_state;               
	private String scp_sv_state2;               
	private String file_xring1;               
	private String file_xring2;               
	private String file_xring3;               
	private int file_code1;               
	private int file_code2;               
	private int file_code3;               
	private String jukechk1;               
	private String jukechk2;               
	private String jukechk3;               
	private long metaseq;               
	private int ktf_lid;               
	private String unlimited_sv;               
	private String file_lring1;               
	private String file_lring2;               
	private String file_lring3;               
	private int r19_licence_tf;               
	private int file_lcode1;               
	private int file_lcode2;               
	private int file_lcode3;	
	private List<TbFileServiceMap2> tbFileServiceMap2List;
	public int getCate_code() {
		return cate_code;
	}
	public void setCate_code(int cate_code) {
		this.cate_code = cate_code;
	}
	public int getFile_scp_id() {
		return file_scp_id;
	}
	public void setFile_scp_id(int file_scp_id) {
		this.file_scp_id = file_scp_id;
	}
	public int getFile_sub_cpid() {
		return file_sub_cpid;
	}
	public void setFile_sub_cpid(int file_sub_cpid) {
		this.file_sub_cpid = file_sub_cpid;
	}
	public int getFile_sort() {
		return file_sort;
	}
	public void setFile_sort(int file_sort) {
		this.file_sort = file_sort;
	}
	public String getCate_name() {
		return cate_name;
	}
	public void setCate_name(String cate_name) {
		this.cate_name = cate_name;
	}
	public String getFile_scp_svname() {
		return file_scp_svname;
	}
	public void setFile_scp_svname(String file_scp_svname) {
		this.file_scp_svname = file_scp_svname;
	}
	public int getCate_code1() {
		return cate_code1;
	}
	public void setCate_code1(int cate_code1) {
		this.cate_code1 = cate_code1;
	}
	public int getCate_code2() {
		return cate_code2;
	}
	public void setCate_code2(int cate_code2) {
		this.cate_code2 = cate_code2;
	}
	public int getCate_code3() {
		return cate_code3;
	}
	public void setCate_code3(int cate_code3) {
		this.cate_code3 = cate_code3;
	}
	public String getCate_name1() {
		return cate_name1;
	}
	public void setCate_name1(String cate_name1) {
		this.cate_name1 = cate_name1;
	}
	public String getCate_name2() {
		return cate_name2;
	}
	public void setCate_name2(String cate_name2) {
		this.cate_name2 = cate_name2;
	}
	public String getCate_name3() {
		return cate_name3;
	}
	public void setCate_name3(String cate_name3) {
		this.cate_name3 = cate_name3;
	}
	public int getFile_count() {
		return file_count;
	}
	public void setFile_count(int file_count) {
		this.file_count = file_count;
	}
	public int getFile_sort1() {
		return file_sort1;
	}
	public void setFile_sort1(int file_sort1) {
		this.file_sort1 = file_sort1;
	}
	public int getFile_sort2() {
		return file_sort2;
	}
	public void setFile_sort2(int file_sort2) {
		this.file_sort2 = file_sort2;
	}
	public int getFile_sort3() {
		return file_sort3;
	}
	public void setFile_sort3(int file_sort3) {
		this.file_sort3 = file_sort3;
	}
	public String getFile_regdate() {
		return file_regdate;
	}
	public void setFile_regdate(String file_regdate) {
		this.file_regdate = file_regdate;
	}
	public String getFile_title() {
		return file_title;
	}
	public void setFile_title(String file_title) {
		this.file_title = file_title;
	}
	public String getFile_singer() {
		return file_singer;
	}
	public void setFile_singer(String file_singer) {
		this.file_singer = file_singer;
	}
	public String getFile_keyword() {
		return file_keyword;
	}
	public void setFile_keyword(String file_keyword) {
		this.file_keyword = file_keyword;
	}
	public String getFile_scp() {
		return file_scp;
	}
	public void setFile_scp(String file_scp) {
		this.file_scp = file_scp;
	}
	public String getFile_sub_cp() {
		return file_sub_cp;
	}
	public void setFile_sub_cp(String file_sub_cp) {
		this.file_sub_cp = file_sub_cp;
	}
	public int getFile_seq() {
		return file_seq;
	}
	public void setFile_seq(int file_seq) {
		this.file_seq = file_seq;
	}
	public String getScp_sv_state() {
		return scp_sv_state;
	}
	public void setScp_sv_state(String scp_sv_state) {
		this.scp_sv_state = scp_sv_state;
	}
	public String getScp_sv_state2() {
		return scp_sv_state2;
	}
	public void setScp_sv_state2(String scp_sv_state2) {
		this.scp_sv_state2 = scp_sv_state2;
	}
	public String getFile_xring1() {
		return file_xring1;
	}
	public void setFile_xring1(String file_xring1) {
		this.file_xring1 = file_xring1;
	}
	public String getFile_xring2() {
		return file_xring2;
	}
	public void setFile_xring2(String file_xring2) {
		this.file_xring2 = file_xring2;
	}
	public String getFile_xring3() {
		return file_xring3;
	}
	public void setFile_xring3(String file_xring3) {
		this.file_xring3 = file_xring3;
	}
	public int getFile_code1() {
		return file_code1;
	}
	public void setFile_code1(int file_code1) {
		this.file_code1 = file_code1;
	}
	public int getFile_code2() {
		return file_code2;
	}
	public void setFile_code2(int file_code2) {
		this.file_code2 = file_code2;
	}
	public int getFile_code3() {
		return file_code3;
	}
	public void setFile_code3(int file_code3) {
		this.file_code3 = file_code3;
	}
	public String getJukechk1() {
		return jukechk1;
	}
	public void setJukechk1(String jukechk1) {
		this.jukechk1 = jukechk1;
	}
	public String getJukechk2() {
		return jukechk2;
	}
	public void setJukechk2(String jukechk2) {
		this.jukechk2 = jukechk2;
	}
	public String getJukechk3() {
		return jukechk3;
	}
	public void setJukechk3(String jukechk3) {
		this.jukechk3 = jukechk3;
	}
	public long getMetaseq() {
		return metaseq;
	}
	public void setMetaseq(long metaseq) {
		this.metaseq = metaseq;
	}
	public int getKtf_lid() {
		return ktf_lid;
	}
	public void setKtf_lid(int ktf_lid) {
		this.ktf_lid = ktf_lid;
	}
	public String getUnlimited_sv() {
		return unlimited_sv;
	}
	public void setUnlimited_sv(String unlimited_sv) {
		this.unlimited_sv = unlimited_sv;
	}
	public String getFile_lring1() {
		return file_lring1;
	}
	public void setFile_lring1(String file_lring1) {
		this.file_lring1 = file_lring1;
	}
	public String getFile_lring2() {
		return file_lring2;
	}
	public void setFile_lring2(String file_lring2) {
		this.file_lring2 = file_lring2;
	}
	public String getFile_lring3() {
		return file_lring3;
	}
	public void setFile_lring3(String file_lring3) {
		this.file_lring3 = file_lring3;
	}
	public int getR19_licence_tf() {
		return r19_licence_tf;
	}
	public void setR19_licence_tf(int r19_licence_tf) {
		this.r19_licence_tf = r19_licence_tf;
	}
	public int getFile_lcode1() {
		return file_lcode1;
	}
	public void setFile_lcode1(int file_lcode1) {
		this.file_lcode1 = file_lcode1;
	}
	public int getFile_lcode2() {
		return file_lcode2;
	}
	public void setFile_lcode2(int file_lcode2) {
		this.file_lcode2 = file_lcode2;
	}
	public int getFile_lcode3() {
		return file_lcode3;
	}
	public void setFile_lcode3(int file_lcode3) {
		this.file_lcode3 = file_lcode3;
	}
	public List<TbFileServiceMap2> getTbFileServiceMap2List() {
		return tbFileServiceMap2List;
	}
	public void setTbFileServiceMap2List(
			List<TbFileServiceMap2> tbFileServiceMap2List) {
		this.tbFileServiceMap2List = tbFileServiceMap2List;
	}
	

}
