package com.ktf.oem.data;

public class RING {
	
	private String IDX, LID, SINGER, SONG, ALBUM_NAME, CATE_CODE, SHOW_ONOFF, RANKING, PRELISTENURL, PRELISTENURL1, PRELISTENURL2, PRELISTENURL3, AGE_GBN, HD;	
	
	public String getIDX() {
		return IDX;
	}

	public void setIDX(String iDX) {
		IDX = iDX;
	}

	public String getLID() {
		return LID;
	}

	public void setLID(String lID) {
		LID = lID;
	}

	public String getSINGER() {
		return SINGER;
	}

	public void setSINGER(String sINGER) {
		SINGER = sINGER;
	}

	public String getSONG() {
		return SONG;
	}

	public void setSONG(String sONG) {
		SONG = sONG;
	}

	public String getALBUM_NAME() {
		return ALBUM_NAME;
	}

	public void setALBUM_NAME(String aLBUM_NAME) {
		ALBUM_NAME = aLBUM_NAME;
	}

	public String getCATE_CODE() {
		return CATE_CODE;
	}

	public void setCATE_CODE(String cATE_CODE) {
		CATE_CODE = cATE_CODE;
	}

	public String getSHOW_ONOFF() {
		return SHOW_ONOFF;
	}

	public void setSHOW_ONOFF(String sHOW_ONOFF) {
		SHOW_ONOFF = sHOW_ONOFF;
	}

	public String getRANKING() {
		return RANKING;
	}

	public void setRANKING(String rANKING) {
		RANKING = rANKING;
	}

	public String getPRELISTENURL() {
		return PRELISTENURL;
	}

	public void setPRELISTENURL(String pRELISTENURL) {
		PRELISTENURL = pRELISTENURL;
	}

	public String getPRELISTENURL1() {
		return PRELISTENURL1;
	}

	public void setPRELISTENURL1(String pRELISTENURL1) {
		PRELISTENURL1 = pRELISTENURL1;
	}

	public String getPRELISTENURL2() {
		return PRELISTENURL2;
	}

	public void setPRELISTENURL2(String pRELISTENURL2) {
		PRELISTENURL2 = pRELISTENURL2;
	}

	public String getPRELISTENURL3() {
		return PRELISTENURL3;
	}

	public void setPRELISTENURL3(String pRELISTENURL3) {
		PRELISTENURL3 = pRELISTENURL3;
	}

	public String getAGE_GBN() {
		return AGE_GBN;
	}

	public void setAGE_GBN(String aGE_GBN) {
		AGE_GBN = aGE_GBN;
	}

	public String getHD() {
		return HD;
	}

	public void setHD(String hD) {
		HD = hD;
	}

}
